<div class="layout-menu-toggle navbar-nav align-items-xl-center me-3 me-xl-0 d-xl-none">
  <a class="nav-item nav-link px-0 me-xl-4" href="javascript:void(0)">
    <i class="bx bx-menu bx-sm"></i>
  </a>
</div>

<div class="navbar-nav-right d-flex align-items-center" id="navbar-collapse">
  <!-- Search -->
  <div class="navbar-nav align-items-center flex-row">
    <div class="nav-item d-flex align-items-center" style="font-family: Times New Roman;text-align: center;font-weight: bold;">
      <img src="<?php echo e(asset('store.jpeg')); ?>" width="70" height="40">
      <marquee>
       Adelia Florist | Sistem Informasi Penjualan untuk Pengelolaan Stok dan Transaksi | Dirancang Khusus untuk Kemudahan dan Akurasi Pengelola | <?php echo e(date('Y-m-d')); ?> <span id="clock"></span>
     </marquee>
   </div>
 </div>
 <!-- /Search -->

 <ul class="navbar-nav flex-row align-items-center ms-auto">
  <!-- Place this tag where you want the button to render. -->
  <!-- path foto -->
  <li class="nav-item navbar-dropdown dropdown-user dropdown">
    <a class="nav-link dropdown-toggle hide-arrow" href="javascript:void(0);" data-bs-toggle="dropdown">
      <div class="avatar avatar-online">
        <img src="<?php echo e(asset('thumbnail.png')); ?>" alt class="w-px-40 h-40 rounded-circle" />
      </div>
    </a>
    <ul class="dropdown-menu dropdown-menu-end">
     <li>
      <a class="dropdown-item" href="#">
        <div class="d-flex">
          <div class="flex-shrink-0 me-3">
            <div class="avatar avatar-online">
             <?php $__currentLoopData = $userprofil; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <?php if($usp->foto == NULL): ?>
             <img src="<?php echo e(asset('thumbnail.png')); ?>" alt class="w-px-40 h-40 rounded-circle" />
             <?php else: ?>
             <img src="<?php echo e(asset($path_foto)); ?>/<?php echo e($usp->foto); ?>" alt class="w-px-40 h-40 rounded-circle" />
             <?php endif; ?>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           </div>
         </div>
         <div class="flex-grow-1">
          <span class="fw-medium d-block"><?php echo e(Auth::user()->name); ?></span>
          <small class="text-muted"><?php echo e(Auth::user()->level); ?></small>
        </div>
      </div>
    </a>
  </li>
  <li>
    <div class="dropdown-divider"></div>
  </li>
  <li>
    <a class="dropdown-item" href="<?php echo e(route('myprofil')); ?>">
      <i class="bx bx-user me-2"></i>
      <span class="align-middle">Profil Saya</span>
    </a>
  </li>
  <li>
    <div class="dropdown-divider"></div>
  </li>
  <li>
    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>">
      <i class="bx bx-power-off me-2"></i>
      <span class="align-middle">Log Out</span>
    </a>
  </li>
</ul>
</li>
<!--/ User -->
</ul>
</div><?php /**PATH C:\xampp\htdocs\web_sisfor_penjualan_floris\resources\views\page\layout\header.blade.php ENDPATH**/ ?>