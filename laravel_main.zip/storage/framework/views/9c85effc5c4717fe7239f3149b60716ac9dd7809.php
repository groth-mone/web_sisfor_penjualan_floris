<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Export Laporan Penjualan</title>

  <!-- <link rel="stylesheet" href="<?php echo e(asset('print.css')); ?>"> -->
</head>
<style type="text/css">
  @page {
    margin: 100px 25px;
  }

  header {
    position: fixed;
    top: -100px;
    left: 0px;
    right: 0px;
    height: 50px;
    font-size: 20px !important;
    text-align: center;
    line-height: 35px;
  }
  th,
  td {
    font-size: 13px; /* Adjust as needed */
  }

</style>
<body>
 <header>
  Adelia Florist <br>Laporan Penjualan<br>
  <?php if(!empty($_GET['tanggal_awal']) AND !empty($_GET['tanggal_akhir'])): ?>
  <small>Periode : <?php echo e($_GET['tanggal_awal']); ?> - <?php echo e($_GET['tanggal_akhir']); ?></small>
  <?php else: ?>
  <small>Periode : Tahun <?php echo e(date('Y')); ?></small>
  <?php endif; ?>
</center>
</header>
<main>
 <div class="card-body">
  <br>
  User Pengelola/Admin: 
  <?php if(count($user) > 0): ?>
  <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <b><?php echo e($usr->name ?? '-'); ?></b>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <?php else: ?>
  -
  <?php endif; ?>
  <br>
  <br>
  <table style="width: 100%;padding: 0;margin: 0;" cellpadding="5" cellspacing="0" border="1">
    <tbody>
      <?php $nul=0; ?>
      <?php $nul_kurang=0; ?>
      <?php $nul_lebih=0; ?>
      <?php  
      $nul_harga_profit = array('0','0','0');
      ?>
      <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php  
      $result = App\Models\Page\Penjualan::getLaporanDetail($dt->id_penjualan);
      $detail = $result['detail'];
      $pembayaran = $result['pembayaran'];

      $subtotal = $nul+=$dt->total_penjualan;
      ?>
      <tr style="background: #aaa;">
       <th>No.</th>
       <th>Kode</th>
       <th>Tanggal</th>
       <th>Pelanggan</th>
       <th>Total Pesanan</th>
       <th>Total Dibayar</th>
       <th colspan="2">Keterangan</th>
     </tr>
     <tr>
       <td><?php echo e($loop->index+1); ?></td>
       <td><b>#<?php echo e($dt->kode_penjualan); ?></b></td>
       <td><?php echo e($dt->tanggal_penjualan); ?></td>
       <td><?php echo e($dt->pelanggan); ?></td>
       <td>Rp. <?php echo e(number_format($dt->total_penjualan,0,",",".")); ?></td>
       <td>Rp. <?php echo e(number_format($dt->total_pembayaran,0,",",".")); ?></td>
       <td colspan="2"><?php echo e($dt->keterangan_penjualan); ?></td>
     </tr>
     <tr>
      <th colspan="8" align="center">Rincian Penjualan</th>
    </tr>
    <tr style="background: #eee;">
      <th></th>
      <th>Kode Item</th>
      <th>Nama Item</th>
      <th>Harga Beli</th>
      <th>Harga Jual</th>
      <th>Jumlah</th>
      <th>Total Harga</th>
      <th>Profit</th>
    </tr>
    <?php $__currentLoopData = $detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $det): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php  
    $profit = ($det->harga_jual - $det->harga_beli) * $det->jml_penjualan;
    $sub_beli = number_format($nul_harga_profit[0]+=$det->harga_beli,0,",",".");
    $sub_jual = number_format($nul_harga_profit[1]+=$det->harga_jual,0,",",".");
    $sub_profit = number_format($nul_harga_profit[2]+=$profit,0,",",".");
    ?>
    <tr>
      <td></td>
      <td><?php echo e($det->kode_barang); ?></td>
      <td><?php echo e($det->nama_barang); ?></td>
      <td>Rp. <?php echo e(number_format($det->harga_beli,0,",",".")); ?></td>
      <td>Rp. <?php echo e(number_format($det->harga_jual,0,",",".")); ?></td>
      <td><?php echo e($det->jml_penjualan); ?> <?php echo e($det->satuan_barang); ?></td>
      <td>Rp. <?php echo e(number_format($det->harga_jual*$det->jml_penjualan,0,",",".")); ?></td>
      <td>Rp. <?php echo e(number_format(($det->harga_jual - $det->harga_beli) * $det->jml_penjualan, 0, ",", ".")); ?></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <th colspan="8" align="center">Metode Pembayaran</th>
    </tr>
    <tr style="background: #eee;">
      <th></th>
      <th>Metode Pembayaran</th>
      <th>Nominal Pembayaran</th>
      <th colspan="5" align="left">Tanggal Pembayaran</th>
    </tr>
    <?php $__currentLoopData = $pembayaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <td></td>
      <td>
        <?php echo e($pem->metode_pembayaran); ?>

        <?php if($pem->metode_detail != NULL): ?>
        (<?php echo e($pem->metode_detail); ?>)
        <?php endif; ?>
      </td>
      <td>Rp. <?php echo e(number_format($pem->nominal_pembayaran,0,",",".")); ?></td>
      <td colspan="5">
        <?php if($pem->tanggal_pembayaran == NULL): ?>
        -
        <?php else: ?>
        <?php echo e($pem->tanggal_pembayaran); ?>

        <?php endif; ?>
      </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>
<?php if(!empty($subtotal)): ?>
<h3>
  Subtotal Penjualan 
  <?php if(!empty($_GET['tanggal_awal']) AND !empty($_GET['tanggal_akhir'])): ?>
  Dari Tanggal : <?php echo e($_GET['tanggal_awal']); ?> - <?php echo e($_GET['tanggal_akhir']); ?>

  <?php else: ?>
  <!-- Semua Periode -->
  Periode : Tahun <?php echo e(date('Y')); ?>

  <?php endif; ?>
  = Rp. <?php echo e(number_format($subtotal,0,",",".")); ?>

  <hr>
  Harga Beli : Rp. <?php echo e($sub_beli ? $sub_beli : '0'); ?><br>
  Harga Jual : Rp. <?php echo e($sub_jual ? $sub_jual : '0'); ?><br>
  Profit : Rp. <?php echo e($sub_profit ? $sub_profit : '0'); ?><br>
</h3>
<?php endif; ?>
</div>
</main>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\web_sisfor_penjualan_floris\resources\views\page\laporan\penjualan\export.blade.php ENDPATH**/ ?>