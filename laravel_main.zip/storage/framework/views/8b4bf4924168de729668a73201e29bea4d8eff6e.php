<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Export Laporan Pembelian</title>

  <!-- <link rel="stylesheet" href="<?php echo e(asset('print.css')); ?>"> -->
</head>
<style type="text/css">
  @page {
    margin: 100px 25px;
  }

  header {
    position: fixed;
    top: -100px;
    left: 0px;
    right: 0px;
    height: 50px;
    font-size: 20px !important;
    text-align: center;
    line-height: 35px;
  }
  th,
  td {
    font-size: 13px; /* Adjust as needed */
  }

</style>
<body>
 <header>
  Adelia Florist <br>Laporan Pembelian<br>
  <?php if(!empty($_GET['awal']) AND !empty($_GET['akhir'])): ?>
  <small>Periode : <?php echo e($_GET['awal']); ?> - <?php echo e($_GET['akhir']); ?></small>
  <?php else: ?>
  <small>Periode : Tahun <?php echo e(date('Y')); ?></small>
  <?php endif; ?>
</center>
</header>
<!-- <footer>
  <center>
    ARS NURSERY <br>Laporan Pembelian<br>
  </center>
</footer> -->
<main>
 <div class="card-body">
  <br>
  <table style="width: 100%;padding: 0;margin: 0;" cellpadding="5" cellspacing="0" border="1">
  <!--   <thead>
      
  </thead> -->
  <tbody>
    <?php $nul=0; ?>
    <?php $nul_kurang=0; ?>
    <?php $nul_lebih=0; ?>
    <?php  
    $nul_harga_profit = array('0','0','0');
    ?>
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php  
    $detail = App\Models\Page\Pembelian::getLaporanDetail($dt->id_pembelian);
    $subtotal = $nul+=$dt->total_penjualan;
    ?>
    <tr style="background: #aaa;">
      <th data-priority="1" class="">No. </th>
      <th data-priority="3" class="">Kode</th>
      <th data-priority="4" class="">Tanggal</th>
      <th data-priority="5" class="">Supplier</th>
      <th data-priority="6" class="">Jumlah Bahan</th>
      <th data-priority="7" class="">Total Pembelian</th>
      <th data-priority="8" class="">Keterangan</th>
    </tr>
    <tr>
      <td><?php echo e($loop->index+1); ?>.</td>
      <td><?php echo e($dt->kode_pembelian); ?></td>
      <td><?php echo e($dt->tanggal_pembelian); ?></td>
      <td><?php echo e($dt->nama_supplier); ?></td>
      <td><?php echo e($dt->jumlah_barang_dibeli); ?> bahan dibeli</td>
      <td>Rp. <?php echo e(number_format($dt->total_pembelian,0,",",".")); ?></td>
      <td><?php echo e($dt->keterangan_pembelian); ?></td>
    </tr>
    <tr>
      <th colspan="8" align="center">Rincian Pembelian</th>
    </tr>
    <tr style="background: #eee;">
      <th></th>
      <th>Kode Bahan</th>
      <th>Nama Bahan</th>
      <th>Harga Beli</th>
      <th>Harga Jual</th>
      <th>Jumlah</th>
      <th>Total Harga</th>
    </tr>
    <?php $__currentLoopData = $detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $det): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php  
    $sub_beli = number_format($nul_harga_profit[0]+=$det->harga_beli,0,",",".");
    $sub_jual = number_format($nul_harga_profit[1]+=$det->harga_jual,0,",",".");
    ?>
    <tr>
      <td></td>
      <td><?php echo e($det->kode_barang); ?></td>
      <td><?php echo e($det->nama_barang); ?></td>
      <td>Rp. <?php echo e(number_format($det->harga_beli,0,",",".")); ?></td>
      <td>Rp. <?php echo e(number_format($det->harga_jual,0,",",".")); ?></td>
      <td><?php echo e($det->jml_pembelian); ?> <?php echo e($det->satuan_barang); ?></td>
      <td>Rp. <?php echo e(number_format($det->harga_beli*$det->jml_pembelian,0,",",".")); ?></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>
<?php if(!empty($subtotal)): ?>
<h3>
  Subtotal Penjualan 
  <?php if(!empty($_GET['awal']) AND !empty($_GET['akhir'])): ?>
  Dari Tanggal : <?php echo e(tanggal_indonesia($_GET['awal'])); ?> - <?php echo e(tanggal_indonesia($_GET['akhir'])); ?>

  <?php else: ?>
  <!-- Semua Periode -->
  Periode : Tahun <?php echo e(date('Y')); ?>

  <?php endif; ?>
  = Rp. <?php echo e(number_format($subtotal,0,",",".")); ?>

  <hr>
  Harga Beli : Rp. <?php echo e($sub_beli ? $sub_beli : '0'); ?><br>
  Harga Jual : Rp. <?php echo e($sub_jual ? $sub_jual : '0'); ?><br>
</h3>
<?php endif; ?>
</div>
</main>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\web_sisfor_penjualan_floris\resources\views\page\laporan\pembelian\export.blade.php ENDPATH**/ ?>