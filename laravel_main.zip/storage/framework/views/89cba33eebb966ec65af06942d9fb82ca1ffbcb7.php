  

  <?php $__env->startSection('title','Laporan Bahan'); ?>

  <?php $__env->startSection('content'); ?>
  <div class="loading" id="loading" style="display: none;">
    <div class="lds-roller"><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div></div>
    <h4>Loading</h4>
  </div>
  <div class="page-heading">
    <div class="page-title">
      <div class="row">
        <div class="col-12 col-md-6 order-md-1 order-last">
        </div>
        <div class="col-12 col-md-6 order-md-2 order-first">
          <nav aria-label="breadcrumb" class="breadcrumb-header float-start float-lg-end">
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="">Laporan</a></li>
              <li class="breadcrumb-item active" aria-current="page">Bahan</li>
            </ol>
          </nav>
        </div>
      </div>
      <div class="row mb-4">
        <div class="col-xl-6 pb-4" style="background: white;box-shadow:2px 2px grey;">
          <form method="GET">
            <div class="row mt-3">
              <label class="col-sm-3 form-label mt-2" style="color: black;">Bahan</label>
              <div class="col-sm-8">
                <select class="form-control" id="barang" name="barang">
                  <option value="">.: PILIH BAHAN :.</option>
                  <?php $__currentLoopData = $barang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($brg->id_barang); ?>" 
                    <?php if(request()->get('barang') == $brg->id_barang): ?> selected <?php endif; ?>>
                    <?php echo e($brg->nama_barang); ?>

                  </option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
            </div>
            <div class="row mt-3">
              <label class="col-sm-3 form-label mt-2" style="color: black;">Tanggal Awal</label>
              <div class="col-sm-8">
                <input type="date" value="<?php echo e(request()->has('tanggal_awal') ? request()->input('tanggal_awal') : ''); ?>" class="form-control" name="tanggal_awal">
              </div>
            </div>
            <div class="row mt-3">
              <label class="col-sm-3 form-label mt-2" style="color: black;">Tanggal Akhir</label>
              <div class="col-sm-8">
                <input type="date" value="<?php echo e(request()->has('tanggal_akhir') ? request()->input('tanggal_akhir') : ''); ?>" class="form-control" name="tanggal_akhir">
              </div>
            </div>
            <button class="btn btn-info mt-4"><i class="fa fa-filter"></i> Tampilkan</button>
            <a href="<?php echo e(route('laporan.barang')); ?>" class="btn btn-secondary mt-4"><i class="bx bx-refresh"></i></a>
            <?php if(!empty($_GET['barang'])): ?>
            <a href="<?php echo e(route('export.barang',['tanggal_awal'=>request()->has('tanggal_awal') ? request()->input('tanggal_awal') : '','tanggal_akhir'=>request()->has('tanggal_akhir') ? request()->input('tanggal_akhir') : '','barang'=>request()->has('barang') ? request()->input('barang') : ''])); ?>" target="_blank" style="float: right;" class="btn btn-danger mt-4"><i class="bx bxs-file-pdf"></i></a>
            <?php endif; ?>
          </form>
        </div>
      </div>
    </div>
    <section class="section">
      <div class="card">
        <div class="card-header">
          <h5 class="card-title mb-0">
            Laporan Persediaan Bahan
          </h5>
        </div>
        <div class="card-body">
          <div class="table-responsive text-nowrap">
            <table class="table table-striped datatable" border="1" cellpadding="0" cellspacing="0" style="width: 100%;">
              <thead>
                <tr>
                 <th data-priority="" class="" rowspan="2">No. </th>
                 <th data-priority="" class="" rowspan="2">Tanggal</th>
                 <th data-priority="" class="" rowspan="2">Kode Transaksi</th>
                 <th data-priority="" class="" rowspan="2">Jenis</th>
                 <th data-priority="" class="" colspan="3" style="text-align: center;">Pembelian</th>
                 <th data-priority="" class="" colspan="3" style="text-align: center;">Penjualan</th>
                 <th data-priority="" class="" colspan="3" style="text-align: center;">Persediaan</th>
               </tr>
               <tr>
                 <th data-priority="" class="">QTY</th>
                 <th data-priority="" class="">Harga</th>
                 <th data-priority="" class="">Total Harga</th>
                 <th data-priority="" class="">QTY</th>
                 <th data-priority="" class="">Harga</th>
                 <th data-priority="" class="">Total Harga</th>
                 <th data-priority="" class="">Stok</th>
                 <th data-priority="" class="">Harga</th>
                 <th data-priority="" class="">Total Harga</th>
               </tr>
             </thead>
             <tbody>
              <?php $counter = 1; ?>
              <?php $__currentLoopData = $combined; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $com): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><?php echo e($counter++); ?></td>
                <td><?php echo e($com['tanggal']); ?></td>
                <td><?php echo e($com['kode']); ?></td>
                <td><?php echo e($com['jenis'] ?? '-'); ?></td>
                <td><?php echo e($com['qty_pembelian'] ? $com['qty_pembelian'] : '-'); ?></td>
                <td><?php echo e($com['harga_pembelian'] ? number_format($com['harga_pembelian'], 0, ',', '.') : '-'); ?></td>
                <td><?php echo e($com['total_pembelian'] ? number_format($com['total_pembelian'], 0, ',', '.') : '-'); ?></td>

                <td><?php echo e($com['qty_penjualan'] ? $com['qty_penjualan'] : '-'); ?></td>
                <td><?php echo e($com['harga_penjualan'] ? number_format($com['harga_penjualan'], 0, ',', '.') : '-'); ?></td>
                <td><?php echo e($com['total_penjualan'] ? number_format($com['total_penjualan'], 0, ',', '.') : '-'); ?></td>

                <td><?php echo e($com['sisa_stok'] ? $com['sisa_stok'] : '-'); ?></td>
                <td><?php echo e($com['harga_persediaan'] ? number_format($com['harga_persediaan'], 0, ',', '.') : '-'); ?></td>
                <td><?php echo e($com['total_persediaan'] ? number_format($com['total_persediaan'], 0, ',', '.') : '-'); ?></td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </section>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script type="text/javascript">
  $(function () {
    $('.datatable').DataTable({
      // order: [[2, 'desc']],
      processing: true,
      pageLength: 10
    });
  });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('page/layout/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\web_sisfor_penjualan_floris\resources\views\page\laporan\barang\index.blade.php ENDPATH**/ ?>