<?php

/*
|--------------------------------------------------------------------------
| Load The Cached Routes
|--------------------------------------------------------------------------
|
| Here we will decode and unserialize the RouteCollection instance that
| holds all of the route information for an application. This allows
| us to instantaneously load the entire route map into the router.
|
*/

app('router')->setCompiledRoutes(
    array (
  'compiled' => 
  array (
    0 => false,
    1 => 
    array (
      '/sanctum/csrf-cookie' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'sanctum.csrf-cookie',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/user' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::puJnWi7qMI0NMkVG',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/clear' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::37BBFOuRRVGevFZg',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'login',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/login/request' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'request.login',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/page/dashboard' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'index.dashboard',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/page/master_inventaris/kategori' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'index.kategori',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/page/master_inventaris/kategori/save' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'save.kategori',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/page/master_inventaris/kategori/update' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'update.kategori',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/page/master_inventaris/barang' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'index.barang',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/page/master_inventaris/barang/save' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'save.barang',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/page/master_inventaris/barang/update' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'update.barang',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/page/master_inventaris/produk' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'index.produk',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/page/master_inventaris/produk/save' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'save.produk',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/page/master_inventaris/produk/update' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'update.produk',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/page/master_inventaris/supplier' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'index.supplier',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/page/master_inventaris/supplier/save' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'save.supplier',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/page/master_inventaris/supplier/update' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'update.supplier',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/page/master_user/pengelola' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'index.pengelola',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/page/master_user/pengelola/save' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'save.pengelola',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/page/master_user/pengelola/update' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'update.pengelola',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/page/master_user/pelanggan' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'index.pelanggan',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/page/master_user/pelanggan/save' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'save.pelanggan',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/page/master_user/pelanggan/update' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'update.pelanggan',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/page/transaksi/pembelian' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'index.pembelian',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/page/transaksi/pembelian/save' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'save.pembelian',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/page/transaksi/pembelian/update' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'update.pembelian',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/page/transaksi/penjualan' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'index.penjualan',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/page/transaksi/penjualan/save' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'save.penjualan',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/page/transaksi/penjualan/update' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'update.penjualan',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/page/laporan/pembelian' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'laporan.pembelian',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/page/laporan/pembelian/export' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'export.pembelian',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/page/laporan/penjualan' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'laporan.penjualan',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/page/laporan/penjualan/export' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'export.penjualan',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/page/laporan/barang' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'laporan.barang',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/page/laporan/barang/export' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'export.barang',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/page/myprofil' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'myprofil',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/page/myprofil/update' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'update_profil',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/back/auth/logout' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'logout',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
    ),
    2 => 
    array (
      0 => '{^(?|/page/(?|master_(?|inventaris/(?|kategori/(?|get_edit/([^/]++)(*:69)|destroy/([^/]++)(*:92))|barang/(?|get_edit/([^/]++)(*:127)|destroy/([^/]++)(*:151))|produk/(?|get_edit/([^/]++)(*:187)|destroy/([^/]++)(*:211))|supplier/(?|get_edit/([^/]++)(*:249)|destroy/([^/]++)(*:273)))|user/pe(?|ngelola/(?|get_edit/([^/]++)(*:321)|destroy/([^/]++)(*:345))|langgan/(?|get_edit/([^/]++)(*:382)|destroy/([^/]++)(*:406))))|transaksi/pe(?|mbelian/(?|get_edit/([^/]++)(*:460)|destroy/([^/]++)(*:484))|njualan/(?|get_edit/([^/]++)(*:521)|destroy/([^/]++)(*:545)|confirm/([^/]++)(*:569)|invoice/([^/]++)(*:593)))))/?$}sDu',
    ),
    3 => 
    array (
      69 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::t97U0fEf8bgRnKGB',
          ),
          1 => 
          array (
            0 => 'id_kategori',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      92 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Yf6tvYjHdWwrT3JL',
          ),
          1 => 
          array (
            0 => 'id_kategori',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      127 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ar4v9dismj0uDgM0',
          ),
          1 => 
          array (
            0 => 'id_barang',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      151 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::KolJrbQ4qtUWB9kM',
          ),
          1 => 
          array (
            0 => 'id_barang',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      187 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::kKV3xxfOSs5MiKBC',
          ),
          1 => 
          array (
            0 => 'id_produk',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      211 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::01bxS0pVdA0SOPJv',
          ),
          1 => 
          array (
            0 => 'id_produk',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      249 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::c3OE8SQmhrXD3elV',
          ),
          1 => 
          array (
            0 => 'id_supplier',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      273 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::eExYBPOFyckfUvu1',
          ),
          1 => 
          array (
            0 => 'id_supplier',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      321 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::83NG0Bwk0USXgdPk',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      345 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::DaQiM7im03NYQLLp',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      382 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::u8xEapqumZFOcq99',
          ),
          1 => 
          array (
            0 => 'id_pelanggan',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      406 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::G5pIvORiyjuufckw',
          ),
          1 => 
          array (
            0 => 'id_pelanggan',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      460 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::R4tCUZQzHZDwD5X3',
          ),
          1 => 
          array (
            0 => 'id_pembelian',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      484 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::toNcRqXQlaMcon1D',
          ),
          1 => 
          array (
            0 => 'id_pembelian',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      521 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::QMVg4tGbo9S6sMvF',
          ),
          1 => 
          array (
            0 => 'id_penjualan',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      545 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::BHx6kbqnpfvJaCez',
          ),
          1 => 
          array (
            0 => 'id_penjualan',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      569 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::4ITKJCZavfls7LXg',
          ),
          1 => 
          array (
            0 => 'id_penjualan',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      593 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'invoice.penjualan',
          ),
          1 => 
          array (
            0 => 'id_penjualan',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => NULL,
          1 => NULL,
          2 => NULL,
          3 => NULL,
          4 => false,
          5 => false,
          6 => 0,
        ),
      ),
    ),
    4 => NULL,
  ),
  'attributes' => 
  array (
    'sanctum.csrf-cookie' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'sanctum/csrf-cookie',
      'action' => 
      array (
        'uses' => 'Laravel\\Sanctum\\Http\\Controllers\\CsrfCookieController@show',
        'controller' => 'Laravel\\Sanctum\\Http\\Controllers\\CsrfCookieController@show',
        'namespace' => NULL,
        'prefix' => 'sanctum',
        'where' => 
        array (
        ),
        'middleware' => 
        array (
          0 => 'web',
        ),
        'as' => 'sanctum.csrf-cookie',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::puJnWi7qMI0NMkVG' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/user',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:295:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:77:"function (\\Illuminate\\Http\\Request $request) {
    return $request->user();
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"00000000000003040000000000000000";}";s:4:"hash";s:44:"Z2oYGoVZcDfY4Z+xGOOQEsVQHfQy0vzYEoREhU3ToCI=";}}',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::puJnWi7qMI0NMkVG',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::37BBFOuRRVGevFZg' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'clear',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'ceklevel:Owner,Admin',
        ),
        'uses' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:591:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:372:"function() {
	\\Illuminate\\Support\\Facades\\Artisan::call(\'cache:clear\');
	\\Illuminate\\Support\\Facades\\Artisan::call(\'config:cache\');
	\\Illuminate\\Support\\Facades\\Artisan::call(\'config:clear\');
	\\Illuminate\\Support\\Facades\\Artisan::call(\'view:clear\');
	\\Illuminate\\Support\\Facades\\Artisan::call(\'route:clear\');
	\\dd("Sudah Bersih nih!, Silahkan Kembali ke Halaman Utama");
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"00000000000003070000000000000000";}";s:4:"hash";s:44:"TPFjqHqKjeAvsrn6DvKTgtQV33060cmvlVbBjlrU9Wo=";}}',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::37BBFOuRRVGevFZg',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'login' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '/',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:257:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:39:"function () {
	return \\view(\'login\');
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"00000000000003060000000000000000";}";s:4:"hash";s:44:"gPZkl6ciA7aVe/6PNds6LXfnRNElkBoqIF5OZSqilTM=";}}',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'login',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'request.login' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'login/request',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\AuthController@request_login',
        'controller' => 'App\\Http\\Controllers\\Auth\\AuthController@request_login',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'request.login',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'index.dashboard' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'page/dashboard',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Page\\DashboardController@dashboard',
        'controller' => 'App\\Http\\Controllers\\Page\\DashboardController@dashboard',
        'namespace' => NULL,
        'prefix' => '/page',
        'where' => 
        array (
        ),
        'as' => 'index.dashboard',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'index.kategori' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'page/master_inventaris/kategori',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'auth',
          3 => 'ceklevel:Owner,Admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Page\\KategoriController@index',
        'controller' => 'App\\Http\\Controllers\\Page\\KategoriController@index',
        'namespace' => NULL,
        'prefix' => 'page/master_inventaris',
        'where' => 
        array (
        ),
        'as' => 'index.kategori',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'save.kategori' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'page/master_inventaris/kategori/save',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'auth',
          3 => 'ceklevel:Owner,Admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Page\\KategoriController@save',
        'controller' => 'App\\Http\\Controllers\\Page\\KategoriController@save',
        'namespace' => NULL,
        'prefix' => 'page/master_inventaris',
        'where' => 
        array (
        ),
        'as' => 'save.kategori',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::t97U0fEf8bgRnKGB' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'page/master_inventaris/kategori/get_edit/{id_kategori}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'auth',
          3 => 'ceklevel:Owner,Admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Page\\KategoriController@get_edit',
        'controller' => 'App\\Http\\Controllers\\Page\\KategoriController@get_edit',
        'namespace' => NULL,
        'prefix' => 'page/master_inventaris',
        'where' => 
        array (
        ),
        'as' => 'generated::t97U0fEf8bgRnKGB',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'update.kategori' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'page/master_inventaris/kategori/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'auth',
          3 => 'ceklevel:Owner,Admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Page\\KategoriController@update',
        'controller' => 'App\\Http\\Controllers\\Page\\KategoriController@update',
        'namespace' => NULL,
        'prefix' => 'page/master_inventaris',
        'where' => 
        array (
        ),
        'as' => 'update.kategori',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Yf6tvYjHdWwrT3JL' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'page/master_inventaris/kategori/destroy/{id_kategori}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'auth',
          3 => 'ceklevel:Owner,Admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Page\\KategoriController@delete',
        'controller' => 'App\\Http\\Controllers\\Page\\KategoriController@delete',
        'namespace' => NULL,
        'prefix' => 'page/master_inventaris',
        'where' => 
        array (
        ),
        'as' => 'generated::Yf6tvYjHdWwrT3JL',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'index.barang' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'page/master_inventaris/barang',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'auth',
          3 => 'ceklevel:Owner,Admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Page\\BarangController@index',
        'controller' => 'App\\Http\\Controllers\\Page\\BarangController@index',
        'namespace' => NULL,
        'prefix' => 'page/master_inventaris',
        'where' => 
        array (
        ),
        'as' => 'index.barang',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'save.barang' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'page/master_inventaris/barang/save',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'auth',
          3 => 'ceklevel:Owner,Admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Page\\BarangController@save',
        'controller' => 'App\\Http\\Controllers\\Page\\BarangController@save',
        'namespace' => NULL,
        'prefix' => 'page/master_inventaris',
        'where' => 
        array (
        ),
        'as' => 'save.barang',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ar4v9dismj0uDgM0' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'page/master_inventaris/barang/get_edit/{id_barang}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'auth',
          3 => 'ceklevel:Owner,Admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Page\\BarangController@get_edit',
        'controller' => 'App\\Http\\Controllers\\Page\\BarangController@get_edit',
        'namespace' => NULL,
        'prefix' => 'page/master_inventaris',
        'where' => 
        array (
        ),
        'as' => 'generated::ar4v9dismj0uDgM0',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'update.barang' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'page/master_inventaris/barang/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'auth',
          3 => 'ceklevel:Owner,Admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Page\\BarangController@update',
        'controller' => 'App\\Http\\Controllers\\Page\\BarangController@update',
        'namespace' => NULL,
        'prefix' => 'page/master_inventaris',
        'where' => 
        array (
        ),
        'as' => 'update.barang',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::KolJrbQ4qtUWB9kM' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'page/master_inventaris/barang/destroy/{id_barang}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'auth',
          3 => 'ceklevel:Owner,Admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Page\\BarangController@delete',
        'controller' => 'App\\Http\\Controllers\\Page\\BarangController@delete',
        'namespace' => NULL,
        'prefix' => 'page/master_inventaris',
        'where' => 
        array (
        ),
        'as' => 'generated::KolJrbQ4qtUWB9kM',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'index.produk' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'page/master_inventaris/produk',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'auth',
          3 => 'ceklevel:Owner,Admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Page\\ProdukController@index',
        'controller' => 'App\\Http\\Controllers\\Page\\ProdukController@index',
        'namespace' => NULL,
        'prefix' => 'page/master_inventaris',
        'where' => 
        array (
        ),
        'as' => 'index.produk',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'save.produk' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'page/master_inventaris/produk/save',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'auth',
          3 => 'ceklevel:Owner,Admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Page\\ProdukController@save',
        'controller' => 'App\\Http\\Controllers\\Page\\ProdukController@save',
        'namespace' => NULL,
        'prefix' => 'page/master_inventaris',
        'where' => 
        array (
        ),
        'as' => 'save.produk',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::kKV3xxfOSs5MiKBC' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'page/master_inventaris/produk/get_edit/{id_produk}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'auth',
          3 => 'ceklevel:Owner,Admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Page\\ProdukController@get_edit',
        'controller' => 'App\\Http\\Controllers\\Page\\ProdukController@get_edit',
        'namespace' => NULL,
        'prefix' => 'page/master_inventaris',
        'where' => 
        array (
        ),
        'as' => 'generated::kKV3xxfOSs5MiKBC',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'update.produk' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'page/master_inventaris/produk/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'auth',
          3 => 'ceklevel:Owner,Admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Page\\ProdukController@update',
        'controller' => 'App\\Http\\Controllers\\Page\\ProdukController@update',
        'namespace' => NULL,
        'prefix' => 'page/master_inventaris',
        'where' => 
        array (
        ),
        'as' => 'update.produk',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::01bxS0pVdA0SOPJv' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'page/master_inventaris/produk/destroy/{id_produk}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'auth',
          3 => 'ceklevel:Owner,Admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Page\\ProdukController@delete',
        'controller' => 'App\\Http\\Controllers\\Page\\ProdukController@delete',
        'namespace' => NULL,
        'prefix' => 'page/master_inventaris',
        'where' => 
        array (
        ),
        'as' => 'generated::01bxS0pVdA0SOPJv',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'index.supplier' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'page/master_inventaris/supplier',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'auth',
          3 => 'ceklevel:Owner,Admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Page\\SupplierController@index',
        'controller' => 'App\\Http\\Controllers\\Page\\SupplierController@index',
        'namespace' => NULL,
        'prefix' => 'page/master_inventaris',
        'where' => 
        array (
        ),
        'as' => 'index.supplier',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'save.supplier' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'page/master_inventaris/supplier/save',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'auth',
          3 => 'ceklevel:Owner,Admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Page\\SupplierController@save',
        'controller' => 'App\\Http\\Controllers\\Page\\SupplierController@save',
        'namespace' => NULL,
        'prefix' => 'page/master_inventaris',
        'where' => 
        array (
        ),
        'as' => 'save.supplier',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::c3OE8SQmhrXD3elV' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'page/master_inventaris/supplier/get_edit/{id_supplier}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'auth',
          3 => 'ceklevel:Owner,Admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Page\\SupplierController@get_edit',
        'controller' => 'App\\Http\\Controllers\\Page\\SupplierController@get_edit',
        'namespace' => NULL,
        'prefix' => 'page/master_inventaris',
        'where' => 
        array (
        ),
        'as' => 'generated::c3OE8SQmhrXD3elV',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'update.supplier' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'page/master_inventaris/supplier/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'auth',
          3 => 'ceklevel:Owner,Admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Page\\SupplierController@update',
        'controller' => 'App\\Http\\Controllers\\Page\\SupplierController@update',
        'namespace' => NULL,
        'prefix' => 'page/master_inventaris',
        'where' => 
        array (
        ),
        'as' => 'update.supplier',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::eExYBPOFyckfUvu1' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'page/master_inventaris/supplier/destroy/{id_supplier}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'auth',
          3 => 'ceklevel:Owner,Admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Page\\SupplierController@delete',
        'controller' => 'App\\Http\\Controllers\\Page\\SupplierController@delete',
        'namespace' => NULL,
        'prefix' => 'page/master_inventaris',
        'where' => 
        array (
        ),
        'as' => 'generated::eExYBPOFyckfUvu1',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'index.pengelola' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'page/master_user/pengelola',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'auth',
          3 => 'ceklevel:Owner,Admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Page\\UserController@index_pengelola',
        'controller' => 'App\\Http\\Controllers\\Page\\UserController@index_pengelola',
        'namespace' => NULL,
        'prefix' => 'page/master_user',
        'where' => 
        array (
        ),
        'as' => 'index.pengelola',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'save.pengelola' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'page/master_user/pengelola/save',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'auth',
          3 => 'ceklevel:Owner,Admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Page\\UserController@save_pengelola',
        'controller' => 'App\\Http\\Controllers\\Page\\UserController@save_pengelola',
        'namespace' => NULL,
        'prefix' => 'page/master_user',
        'where' => 
        array (
        ),
        'as' => 'save.pengelola',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::83NG0Bwk0USXgdPk' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'page/master_user/pengelola/get_edit/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'auth',
          3 => 'ceklevel:Owner,Admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Page\\UserController@get_edit_pengelola',
        'controller' => 'App\\Http\\Controllers\\Page\\UserController@get_edit_pengelola',
        'namespace' => NULL,
        'prefix' => 'page/master_user',
        'where' => 
        array (
        ),
        'as' => 'generated::83NG0Bwk0USXgdPk',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'update.pengelola' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'page/master_user/pengelola/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'auth',
          3 => 'ceklevel:Owner,Admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Page\\UserController@update_pengelola',
        'controller' => 'App\\Http\\Controllers\\Page\\UserController@update_pengelola',
        'namespace' => NULL,
        'prefix' => 'page/master_user',
        'where' => 
        array (
        ),
        'as' => 'update.pengelola',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::DaQiM7im03NYQLLp' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'page/master_user/pengelola/destroy/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'auth',
          3 => 'ceklevel:Owner,Admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Page\\UserController@delete_pengelola',
        'controller' => 'App\\Http\\Controllers\\Page\\UserController@delete_pengelola',
        'namespace' => NULL,
        'prefix' => 'page/master_user',
        'where' => 
        array (
        ),
        'as' => 'generated::DaQiM7im03NYQLLp',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'index.pelanggan' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'page/master_user/pelanggan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'auth',
          3 => 'ceklevel:Owner,Admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Page\\UserController@index_pelanggan',
        'controller' => 'App\\Http\\Controllers\\Page\\UserController@index_pelanggan',
        'namespace' => NULL,
        'prefix' => 'page/master_user',
        'where' => 
        array (
        ),
        'as' => 'index.pelanggan',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'save.pelanggan' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'page/master_user/pelanggan/save',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'auth',
          3 => 'ceklevel:Owner,Admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Page\\UserController@save_pelanggan',
        'controller' => 'App\\Http\\Controllers\\Page\\UserController@save_pelanggan',
        'namespace' => NULL,
        'prefix' => 'page/master_user',
        'where' => 
        array (
        ),
        'as' => 'save.pelanggan',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::u8xEapqumZFOcq99' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'page/master_user/pelanggan/get_edit/{id_pelanggan}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'auth',
          3 => 'ceklevel:Owner,Admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Page\\UserController@get_edit_pelanggan',
        'controller' => 'App\\Http\\Controllers\\Page\\UserController@get_edit_pelanggan',
        'namespace' => NULL,
        'prefix' => 'page/master_user',
        'where' => 
        array (
        ),
        'as' => 'generated::u8xEapqumZFOcq99',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'update.pelanggan' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'page/master_user/pelanggan/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'auth',
          3 => 'ceklevel:Owner,Admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Page\\UserController@update_pelanggan',
        'controller' => 'App\\Http\\Controllers\\Page\\UserController@update_pelanggan',
        'namespace' => NULL,
        'prefix' => 'page/master_user',
        'where' => 
        array (
        ),
        'as' => 'update.pelanggan',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::G5pIvORiyjuufckw' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'page/master_user/pelanggan/destroy/{id_pelanggan}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'auth',
          3 => 'ceklevel:Owner,Admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Page\\UserController@delete_pelanggan',
        'controller' => 'App\\Http\\Controllers\\Page\\UserController@delete_pelanggan',
        'namespace' => NULL,
        'prefix' => 'page/master_user',
        'where' => 
        array (
        ),
        'as' => 'generated::G5pIvORiyjuufckw',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'index.pembelian' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'page/transaksi/pembelian',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'auth',
          3 => 'ceklevel:Owner,Admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Page\\PembelianController@index',
        'controller' => 'App\\Http\\Controllers\\Page\\PembelianController@index',
        'namespace' => NULL,
        'prefix' => 'page/transaksi',
        'where' => 
        array (
        ),
        'as' => 'index.pembelian',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'save.pembelian' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'page/transaksi/pembelian/save',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'auth',
          3 => 'ceklevel:Owner,Admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Page\\PembelianController@save',
        'controller' => 'App\\Http\\Controllers\\Page\\PembelianController@save',
        'namespace' => NULL,
        'prefix' => 'page/transaksi',
        'where' => 
        array (
        ),
        'as' => 'save.pembelian',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::R4tCUZQzHZDwD5X3' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'page/transaksi/pembelian/get_edit/{id_pembelian}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'auth',
          3 => 'ceklevel:Owner,Admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Page\\PembelianController@get_edit',
        'controller' => 'App\\Http\\Controllers\\Page\\PembelianController@get_edit',
        'namespace' => NULL,
        'prefix' => 'page/transaksi',
        'where' => 
        array (
        ),
        'as' => 'generated::R4tCUZQzHZDwD5X3',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'update.pembelian' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'page/transaksi/pembelian/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'auth',
          3 => 'ceklevel:Owner,Admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Page\\PembelianController@update',
        'controller' => 'App\\Http\\Controllers\\Page\\PembelianController@update',
        'namespace' => NULL,
        'prefix' => 'page/transaksi',
        'where' => 
        array (
        ),
        'as' => 'update.pembelian',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::toNcRqXQlaMcon1D' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'page/transaksi/pembelian/destroy/{id_pembelian}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'auth',
          3 => 'ceklevel:Owner,Admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Page\\PembelianController@delete',
        'controller' => 'App\\Http\\Controllers\\Page\\PembelianController@delete',
        'namespace' => NULL,
        'prefix' => 'page/transaksi',
        'where' => 
        array (
        ),
        'as' => 'generated::toNcRqXQlaMcon1D',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'index.penjualan' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'page/transaksi/penjualan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'auth',
          3 => 'ceklevel:Owner,Admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Page\\PenjualanController@index',
        'controller' => 'App\\Http\\Controllers\\Page\\PenjualanController@index',
        'namespace' => NULL,
        'prefix' => 'page/transaksi',
        'where' => 
        array (
        ),
        'as' => 'index.penjualan',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'save.penjualan' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'page/transaksi/penjualan/save',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'auth',
          3 => 'ceklevel:Owner,Admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Page\\PenjualanController@save',
        'controller' => 'App\\Http\\Controllers\\Page\\PenjualanController@save',
        'namespace' => NULL,
        'prefix' => 'page/transaksi',
        'where' => 
        array (
        ),
        'as' => 'save.penjualan',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::QMVg4tGbo9S6sMvF' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'page/transaksi/penjualan/get_edit/{id_penjualan}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'auth',
          3 => 'ceklevel:Owner,Admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Page\\PenjualanController@get_edit',
        'controller' => 'App\\Http\\Controllers\\Page\\PenjualanController@get_edit',
        'namespace' => NULL,
        'prefix' => 'page/transaksi',
        'where' => 
        array (
        ),
        'as' => 'generated::QMVg4tGbo9S6sMvF',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'update.penjualan' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'page/transaksi/penjualan/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'auth',
          3 => 'ceklevel:Owner,Admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Page\\PenjualanController@update',
        'controller' => 'App\\Http\\Controllers\\Page\\PenjualanController@update',
        'namespace' => NULL,
        'prefix' => 'page/transaksi',
        'where' => 
        array (
        ),
        'as' => 'update.penjualan',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::BHx6kbqnpfvJaCez' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'page/transaksi/penjualan/destroy/{id_penjualan}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'auth',
          3 => 'ceklevel:Owner,Admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Page\\PenjualanController@delete',
        'controller' => 'App\\Http\\Controllers\\Page\\PenjualanController@delete',
        'namespace' => NULL,
        'prefix' => 'page/transaksi',
        'where' => 
        array (
        ),
        'as' => 'generated::BHx6kbqnpfvJaCez',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::4ITKJCZavfls7LXg' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'page/transaksi/penjualan/confirm/{id_penjualan}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'auth',
          3 => 'ceklevel:Owner,Admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Page\\PenjualanController@confirm',
        'controller' => 'App\\Http\\Controllers\\Page\\PenjualanController@confirm',
        'namespace' => NULL,
        'prefix' => 'page/transaksi',
        'where' => 
        array (
        ),
        'as' => 'generated::4ITKJCZavfls7LXg',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'invoice.penjualan' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'page/transaksi/penjualan/invoice/{id_penjualan}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'auth',
          3 => 'ceklevel:Owner,Admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Page\\PenjualanController@invoice',
        'controller' => 'App\\Http\\Controllers\\Page\\PenjualanController@invoice',
        'namespace' => NULL,
        'prefix' => 'page/transaksi',
        'where' => 
        array (
        ),
        'as' => 'invoice.penjualan',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'laporan.pembelian' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'page/laporan/pembelian',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'auth',
          3 => 'ceklevel:Owner,Admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Page\\PembelianController@laporan',
        'controller' => 'App\\Http\\Controllers\\Page\\PembelianController@laporan',
        'namespace' => NULL,
        'prefix' => 'page/laporan',
        'where' => 
        array (
        ),
        'as' => 'laporan.pembelian',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'export.pembelian' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'page/laporan/pembelian/export',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'auth',
          3 => 'ceklevel:Owner,Admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Page\\PembelianController@export',
        'controller' => 'App\\Http\\Controllers\\Page\\PembelianController@export',
        'namespace' => NULL,
        'prefix' => 'page/laporan',
        'where' => 
        array (
        ),
        'as' => 'export.pembelian',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'laporan.penjualan' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'page/laporan/penjualan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'auth',
          3 => 'ceklevel:Owner,Admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Page\\PenjualanController@laporan',
        'controller' => 'App\\Http\\Controllers\\Page\\PenjualanController@laporan',
        'namespace' => NULL,
        'prefix' => 'page/laporan',
        'where' => 
        array (
        ),
        'as' => 'laporan.penjualan',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'export.penjualan' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'page/laporan/penjualan/export',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'auth',
          3 => 'ceklevel:Owner,Admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Page\\PenjualanController@export',
        'controller' => 'App\\Http\\Controllers\\Page\\PenjualanController@export',
        'namespace' => NULL,
        'prefix' => 'page/laporan',
        'where' => 
        array (
        ),
        'as' => 'export.penjualan',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'laporan.barang' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'page/laporan/barang',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'auth',
          3 => 'ceklevel:Owner,Admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Page\\BarangController@laporan',
        'controller' => 'App\\Http\\Controllers\\Page\\BarangController@laporan',
        'namespace' => NULL,
        'prefix' => 'page/laporan',
        'where' => 
        array (
        ),
        'as' => 'laporan.barang',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'export.barang' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'page/laporan/barang/export',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'auth',
          3 => 'ceklevel:Owner,Admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Page\\BarangController@export',
        'controller' => 'App\\Http\\Controllers\\Page\\BarangController@export',
        'namespace' => NULL,
        'prefix' => 'page/laporan',
        'where' => 
        array (
        ),
        'as' => 'export.barang',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'myprofil' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'page/myprofil',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Page\\DashboardController@myprofil',
        'controller' => 'App\\Http\\Controllers\\Page\\DashboardController@myprofil',
        'namespace' => NULL,
        'prefix' => '/page',
        'where' => 
        array (
        ),
        'as' => 'myprofil',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'update_profil' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'page/myprofil/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Page\\DashboardController@update_profil',
        'controller' => 'App\\Http\\Controllers\\Page\\DashboardController@update_profil',
        'namespace' => NULL,
        'prefix' => '/page',
        'where' => 
        array (
        ),
        'as' => 'update_profil',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'logout' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'back/auth/logout',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\AuthController@logout',
        'controller' => 'App\\Http\\Controllers\\Auth\\AuthController@logout',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'logout',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
  ),
)
);
